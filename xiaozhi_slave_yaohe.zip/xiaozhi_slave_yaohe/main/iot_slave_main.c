/**
 * @file    iot_slave_main.c
 * @brief   IoT 从机设备主程序
 *
 * 功能：
 * - 初始化 WiFi
 * - 初始化 ESP-NOW 通信
 * - 创建设备控制任务
 *
 * 架构：
 * - esp_now_receive.c   : ESP-NOW 接收 + 命令解析
 * - esp_now_heartbeat.c : 心跳包发送
 * - iot_control_task.c  : 设备标志位刷新 + GPIO 控制
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_now.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "nvs_flash.h"
#include "esp_mac.h"

#include "app_wifi.h"
#include "esp_now_receive.h"
#include "esp_now_heartbeat.h"
#include "iot_control_task.h"

static const char* TAG = "MAIN";

/* ================= 主入口 ================= */
void app_main(void) {
    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, "   IoT Slave Device Starting...");
    ESP_LOGI(TAG, "========================================");

    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    ESP_LOGI(TAG, "Connecting to WiFi...");
    App_WiFi_System_Init();

    ESP_LOGI(TAG, "Initializing ESP-NOW...");
    EspNow_Receive_Init();

    ESP_LOGI(TAG, "Initializing Device Control...");
    Iot_Control_Task_Init();

    ESP_LOGI(TAG, "Initializing Heartbeat...");
    EspNow_Heartbeat_Init();

    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, "   IoT Slave Ready!");
    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, "Waiting for commands...");

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
